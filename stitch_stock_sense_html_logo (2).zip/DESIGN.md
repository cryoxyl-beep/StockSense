---
name: Obsidian Precision Grid
colors:
  surface: '#101419'
  surface-dim: '#101419'
  surface-bright: '#36393f'
  surface-container-lowest: '#0b0e14'
  surface-container-low: '#181c21'
  surface-container: '#1c2025'
  surface-container-high: '#272a30'
  surface-container-highest: '#31353b'
  on-surface: '#e0e2ea'
  on-surface-variant: '#b9cbbd'
  inverse-surface: '#e0e2ea'
  inverse-on-surface: '#2d3136'
  outline: '#849588'
  outline-variant: '#3b4a40'
  surface-tint: '#00e293'
  primary: '#cdffde'
  on-primary: '#003921'
  primary-container: '#00f5a0'
  on-primary-container: '#006b43'
  inverse-primary: '#006c44'
  secondary: '#96edff'
  on-secondary: '#00363e'
  secondary-container: '#00d7f3'
  on-secondary-container: '#005966'
  tertiary: '#caffe1'
  on-tertiary: '#003824'
  tertiary-container: '#61efb2'
  on-tertiary-container: '#006b48'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#50ffaf'
  primary-fixed-dim: '#00e293'
  on-primary-fixed: '#002111'
  on-primary-fixed-variant: '#005232'
  secondary-fixed: '#a1efff'
  secondary-fixed-dim: '#05daf6'
  on-secondary-fixed: '#001f25'
  on-secondary-fixed-variant: '#004e5a'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#101419'
  on-background: '#e0e2ea'
  surface-variant: '#31353b'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3rem
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '800'
    lineHeight: '1.15'
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.625rem
    fontWeight: '700'
    lineHeight: '1.25'
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: '1.25'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.375rem
    fontWeight: '700'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: '1.35'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: '1.45'
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: '1.4'
    letterSpacing: 0.005em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.625rem
    fontWeight: '500'
    lineHeight: '1.15'
    letterSpacing: 0.06em
  data-metric:
    fontFamily: JetBrains Mono
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system establishes a high-frequency telemetry interface engineered for modern inventory intelligence and neo-fintech liquidity tracking. Designed for quantitative operators, supply chain strategists, and fintech analysts, the aesthetic projects relentless precision, total auditability, and calm command under volatility.

The style fuses **Technical Neo-Fintech** with **Precision Cybernetics**:
- Deep, light-absorbing obsidian backdrops anchor the visual field, eliminating extraneous light scatter and visual noise.
- Layered translucent panels with cold-spectrum refractions deliver optical hierarchy without sacrificing contrast.
- Luminous mint and cyan accents communicate live state, real-time recalculations, and positive delta values.
- Subtle reticle markers, precision-aligned corner brackets, and hairline data dividers invoke aerospace heads-up displays and high-frequency trading terminals.
- High data density is balanced through strict mathematical rhythm, uncompromising tabular alignment, and dedicated monospaced readouts for financial and volumetric variables.

## Colors

The palette is tuned for sustained operational focus in low-light trading and logistics environments. The background utilizes a multi-tiered obsidian scale, while accents deliver calibrated visual punch for critical telemetry:

- **Primary Canvas (`#06090E`)**: Deep obsidian base floor. Zero-chroma black bias avoids mudding accent luminescence.
- **Surface Elevation 1 (`#0E131F`)**: Mid-tier structural card backplane and module container background.
- **Surface Elevation 2 (`#141E30`)**: Elevated panels, popovers, flyouts, and active cell hover states.
- **Primary Accent (`#00F5A0`)**: Cybernetic Mint. Used strictly for primary callouts, positive vector differentials, healthy stock thresholds, and focal actionable triggers.
- **Secondary Accent (`#00D9F5`)**: Radiant Cyan. Reserved for liquidity feeds, analytical trends, active selection states, and telemetry data curves.
- **Semantic Signals**:
  - **Success / In-Stock (`#10B981`)**: Deep emerald for verified transactions, stable replenishment rates, and confirmed audits.
  - **Warning / Low Stock (`#F59E0B`)**: Amber for near-depletion alerts, order latency, and margin warnings.
  - **Danger / Critical Stockout (`#F43F5E`)**: Rose-crimson for liquidity deficits, stockouts, and API disconnection states.
- **Structural Lines & Reticles (`rgba(0, 217, 245, 0.12)`)**: Hairline borders, precision grid lines, and targeting brackets.

## Typography

The typographic hierarchy enforces immediate legibility between contextual editorial data and precise transactional telemetry.

- **Plus Jakarta Sans** delivers humanist clarity and geometric structure for operational headlines, executive card summaries, and conversational annotations.
- **JetBrains Mono** serves all non-prose functions: ticker codes, SKU identifications, ledger balances, coordinate tracking, timestamp signatures, and differential indicators.
- **Tabular Figures**: All instances of JetBrains Mono and numeric sequences must enforce `font-variant-numeric: tabular-nums` to eliminate jitter across real-time dynamic streaming updates.
- **Uppercase Discipline**: Micro-labels, table column headers, and status badges render in uppercase with positive letter spacing (`0.04em` to `0.06em`) to guarantee quick recognition in dense grids.

## Layout & Spacing

This design system uses a dense, fluid 12-column layout on desktop, transitioning into an adaptable 8-column format on tablet, and a concentrated 4-column flow on mobile.

- **Breakpoints**:
  - `Mobile`: `< 768px` (4 columns, `margin: 1rem`, `gutter: 1rem`)
  - `Tablet`: `768px - 1199px` (8 columns, `margin: 1.5rem`, `gutter: 1.25rem`)
  - `Desktop`: `≥ 1200px` (12 columns, `margin: 2.5rem`, `gutter: 1.5rem`, max grid width 1600px)
- **Rhythm**: All layout vertical and horizontal coordinates increment on a hard 4px base module (`space-xs` = 4px, `space-sm` = 8px, `space-md` = 16px, `space-lg` = 24px, `space-xl` = 32px).
- **Data Density**: Table rows and analytical matrix cells lock to a strict 36px or 44px vertical stride, preserving information visibility above the scroll fold.

## Elevation & Depth

Visual hierarchy does not rely on diffused drop shadows; depth is instead established via glassmorphic layering, cold tonal shift, and hairline specular light borders:

- **Level 0 (Floor Canvas)**: Solid `#06090E`.
- **Level 1 (Docked Containers & Grid Cells)**: `#0E131F` at 85% opacity, with a `backdrop-filter: blur(16px)` and a continuous 1px outline of `rgba(255, 255, 255, 0.05)`.
- **Level 2 (Interactive Modules & Hover Cards)**: `#141E30` at 70% opacity, `backdrop-filter: blur(24px)`, reinforced by a directional top hairline of `rgba(0, 245, 160, 0.25)` to simulate overhead instrument illumination.
- **Level 3 (Overlays, Command Palettes, Modals)**: `#0E131F` at 95% opacity, `backdrop-filter: blur(32px)`, with a subtle ambient perimeter glow: `0 0 24px rgba(0, 217, 245, 0.08)`.
- **Reticle Embellishments**: High-priority cards feature 4px corner ticks or crosshair tick-marks in the border corners (`border-image` or pseudo-elements tinted at `rgba(0, 245, 160, 0.4)`), asserting an analytical, HUD-inspired aesthetic.

## Shapes

The interface balances sharp architectural lines with subtle edge easing to avoid harsh digital artifacts while retaining an engineered, technical silhouette:

- **Corner Radii**: Standard components apply `rounded-sm` (0.25rem / 4px). Outer container boundaries and complex visual modules scale up to `rounded-lg` (0.5rem / 8px).
- **Inner-to-Outer Conformity**: Nested surfaces maintain nested proportional curves (e.g., an 8px card shell housing a 4px button or input).
- **Pill Exceptions**: Status pill chips and small binary switches utilize full rounding (`9999px`) to create an unambiguous contrast against the structural geometry of the core data grids.

## Components

### Buttons
- **Primary Action**: Solid `#00F5A0` fill, `#06090E` text in JetBrains Mono (`label-lg`), `rounded-sm`, 0 0 16px glow of `rgba(0, 245, 160, 0.2)`. On hover, scale glow intensity without translating the button position.
- **Secondary (HUD Outline)**: Transparent background, 1px border of `rgba(0, 217, 245, 0.3)`, text in `#00D9F5`. Hover activates an inner fill of `rgba(0, 217, 245, 0.08)`.
- **Ghost/Tertiary**: Text in `#94A3B8`, borderless, padding aligned flush with grid guides. Hover triggers `#FFFFFF` text.

### Chips & Badges
- **Status Pills**: Height 22px, `rounded-full`, horizontal padding 8px. Rendered in semi-transparent tints:
  - Nominal: `rgba(0, 245, 160, 0.1)` fill, `#00F5A0` text, 1px border of `rgba(0, 245, 160, 0.3)`.
  - Alert: `rgba(244, 63, 94, 0.1)` fill, `#F43F5E` text, 1px border of `rgba(244, 63, 94, 0.3)`.
- Always pair status chips with a 4px solid pulsing dot indicator.

### Input Fields & Controls
- **Inputs**: Background `#0E131F`, 1px border `rgba(255, 255, 255, 0.1)`, text in Plus Jakarta Sans (`body-md`), typography for numeric inputs forced to JetBrains Mono. Focus states transition the border to `#00D9F5` accompanied by a localized inner glow (`inset 0 0 6px rgba(0, 217, 245, 0.2)`).
- **Checkboxes & Radios**: 16x16px boxes with `rounded-sm` (checkbox) or circular (radio), `#0E131F` surface with 1px `rgba(255, 255, 255, 0.2)` stroke. Checked state illuminates with a solid `#00F5A0` center.

### Data Tables & Lists
- **Telemetry Rows**: Zebra alternating rows prohibited; rows rely on 1px horizontal dividers (`rgba(255, 255, 255, 0.04)`). Row hover triggers an immediate background illumination of `#141E30`.
- **Header Cells**: JetBrains Mono (`label-sm`), uppercase, colored `#64748B`, with explicit sort indicators (▲/▼).

### Cards & Panels
- **HUD Glass Containers**: Background `rgba(14, 19, 31, 0.8)`, 1px border `rgba(0, 217, 245, 0.12)`, `backdrop-filter: blur(16px)`.
- **Telemetry Reticles**: Prominent metrics feature corner crosshairs (`+`) stamped into top-right and bottom-left bounds to complete the tactical inventory terminal aesthetic.